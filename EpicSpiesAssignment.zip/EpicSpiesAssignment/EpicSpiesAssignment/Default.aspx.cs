﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EpicSpiesAssignment
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                calOld.SelectedDate = DateTime.Now.Date;
                calStartNew.SelectedDate = calOld.SelectedDate.AddDays(14);
                calEndNew.SelectedDate = calOld.SelectedDate.AddDays(21);
            }
        }

        protected void goBtn_Click(object sender, EventArgs e)
        {
            int timeBetween = (calStartNew.SelectedDate - calOld.SelectedDate).Days;
            int duration = (calEndNew.SelectedDate - calStartNew.SelectedDate).Days;

            if (timeBetween < 14)
            {
                resultLbl.Text = "Error: Must allow atleast two weeks beetween assignments.";
                calEndNew.SelectedDate = calOld.SelectedDate.AddDays(14); 
            }

            int resultInt = duration < 22 ? duration * 500 : duration * 500 + 1000;

            resultLbl.Text = String.Format("Assignment of " + TBCodeName.Text + " to assignment " + TBNewA.Text + " is authorized. Budget total: {0:c}", resultInt);

            eRLbl1.Text = "";
            eRLbl2.Text = "";
        }

        protected void calStartNew_SelectionChanged(object sender, EventArgs e)
        {
            if (calStartNew.SelectedDate < calOld.SelectedDate)
            {
                calStartNew.SelectedDate = calOld.SelectedDate.AddDays(14);
                eRLbl1.Text = "Error: The start date of a new assignment must be after the end of a previouse assignment.";
            }
            else
            {
                eRLbl1.Text = "";
            }

        }

        protected void calEndNew_SelectionChanged(object sender, EventArgs e)
        {
            if (calEndNew.SelectedDate < calStartNew.SelectedDate)
            {
                calEndNew.SelectedDate = calStartNew.SelectedDate.AddDays(14);
                eRLbl2.Text = "Error: You canot end an assignment before you start it";
            }
            else
            {
                eRLbl2.Text = "";
            }

        }
    }
}