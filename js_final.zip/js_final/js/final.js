
    var text1 = "";
    var text2 = "";
    var runningTotal = 0;

function getSize(text1,text2,runningTotal){
  
    for (var i = 0; i < document.getElementsByName("Size").length; i++){
            if (document.getElementsByName("Size")[i].checked){
                    this.text1 = document.getElementsByName("Size")[i].value+"<br>";
                if(document.getElementsByName("Size")[i].value ==="Extra Large Pizza"){
                    this.text2 = "16.00<br>";
                    this.runningTotal+=16;
                }else if(document.getElementsByName("Size")[i].value ==="Large Pizza"){
                    this.text2 = "14.00<br>";
                    this.runningTotal+=14;     
                }else if(document.getElementsByName("Size")[i].value ==="Medium Pizza"){
                    this.text2 = "10.00<br>";
                    this.runningTotal+=10;    
                }else{
                    this.text2 = "6.00<br>";
                    this.runningTotal+=6;
                };
            }
        }
};


function getMeat(text1,text2,runningTotal){
   
        var count = 0;
         for (var i = 0; i < document.getElementsByName("Meat").length; i++){
            if (document.getElementsByName("Meat")[i].checked){
                if(count==0){
                    this.text1 += document.getElementsByName("Meat")[i].value +"<br>";
                    this.text2 += "No Charge<br>";
                    count++;
                   }else{
                       this.text1 += document.getElementsByName("Meat")[i].value +"<br>";
                       this.text2 += "1.00<br>";
                       this.runningTotal+=1; 
                   }
                
                };
        }
};

function getVeggie(text1,text2,runningTotal) {
    var count = 0;
         for (var i = 0; i < document.getElementsByName("Veggie").length; i++){
            if (document.getElementsByName("Veggie")[i].checked){
                if(count==0){
                    this.text1 += document.getElementsByName("Veggie")[i].value +"<br>";
                    this.text2 += "No Charge<br>";
                    count++;
                   }else{
                       this.text1 += document.getElementsByName("Veggie")[i].value +"<br>";
                       this.text2 += "1.00<br>";
                       this.runningTotal+=1; 
                   }
                
                };
        }
};

function getCheese(text1,text2,runningTotal) {
    
	  for (var i = 0; i < document.getElementsByName("Cheese").length; i++){
            if (document.getElementsByName("Cheese")[i].checked){
                this.text1 += document.getElementsByName("Cheese")[i].value +"<br>";
                if(document.getElementsByName("Cheese")[i].value ==="Extra cheese"){
                    this.text2 += "3.00<br>";
                    this.runningTotal+=3;   
                }else{
                    this.text2 += "No Charge<br>";
                };
            }
        }  
};

function getSauce(text1,text2,runningTotal) {
    
	 for (var i = 0; i < document.getElementsByName("Sauce").length; i++){
            if (document.getElementsByName("Sauce")[i].checked){
                this.text1 += document.getElementsByName("Sauce")[i].value +"<br>";
                this.text2 += "No Charge<br>";
                };
        }
};

function getCrust(text1,text2,runningTotal) {
    
  	 for (var i = 0; i < document.getElementsByName("Crust").length; i++){
            if (document.getElementsByName("Crust")[i].checked){
                this.text1 += document.getElementsByName("Crust")[i].value +"<br>";
                if(document.getElementsByName("Crust")[i].value ==="Cheese Stuffed Crust"){
                    this.text2 += "3.00<br>";
                    this.runningTotal+=3;   
                }else{
                    this.text2 += "No Charge<br>";
                };
            }
        }
};

function showReceipt(text1,text2,runningTotal){
     /*set the display to isable*/
	document.getElementById("insert_text").innerHTML=text1;
	document.getElementById("insert_cost").innerHTML=text2;
	document.getElementById("insert_total").innerHTML = "</h3>$"+runningTotal+".00"+"</h3>";
    document.getElementById('display_cart').style.visibility = 'visible';
};

function clearAll() {
    this.text1="";
    this.text2="";
    this.runningTotal=0;
    document.getElementById("form").reset();
    document.getElementById('display_cart').style.visibility = 'hidden';
};

function getReceipt(){
    this.text1="";
    this.text2="";
    this.runningTotal=0;
    getSize(this.text1,this.text2,this.runningTotal);    
    getCheese(this.text1,this.text2,this.runningTotal);
    getSauce(this.text1,this.text2,this.runningTotal);
    getCrust(this.text1,this.text2,this.runningTotal);
    getMeat(this.text1,this.text2,this.runningTotal); 
    getVeggie(this.text1,this.text2,this.runningTotal);
    showReceipt(this.text1,this.text2,this.runningTotal);
};
