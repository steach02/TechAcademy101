var index_arr = [1,2,3,4,5,6,7,8,9];

function start(){

    reset();
    document.getElementById("9").className="cube";
    this.index_arr = shuffle(index_arr)
               for(var i=1; i<9; i++){
                 document.getElementById(this.index_arr[i]+"").className="cube"+i;
            }

};

function solve(){
    this.index_arr = [1,2,3,4,5,6,7,8,9];
          for(var i=1; i<9; i++){
                    document.getElementById(i+"").className="cube"+i;
            }
        document.getElementById("9").className="cube";
};

function reset(){
        this.index_arr = [1,2,3,4,5,6,7,8,9];
        for(var i=1; i<=9; i++){
                document.getElementById(i+"").className="cube";
        }
        document.getElementById("test").innerHTML=""

};

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
};

function switch_tile(move_to){
    var empty=document.getElementsByClassName("cube")[0].getAttribute("int");
    document.getElementById("test").innerHTML=""
    if(validMove(empty,move_to)){
        document.getElementsByClassName("cube")[0].className=document.getElementById(move_to).className;
        document.getElementById(move_to).className="cube";
    }else{
        document.getElementById("test").innerHTML="<p>invalid move</p>"
    }
};

function validMove(empty,move_to){
     
    switch (empty) {
    case "1":
        if(move_to ="2" || move_to=="4"){
            return true;
        }
        break; 
    case "2":
        if(move_to=="1" || move_to=="3" || move_to=="5"){
            return true;
        }
        break; 
    case "3":
         if(move_to=="2" || move_to=="6"){
            return true;
        }
        break; 
    case "4":
        if(move_to=="1" || move_to=="5" || move_to=="7"){
            return true;
        }
        break; 
    case "5":
          if(move_to=="2" || move_to=="4" || move_to=="6" || move_to=="8"){
            return true;
        }
        break; 
    case "6":
         if(move_to=="3" || move_to=="5" || move_to=="9"){
            return true;
        }
        break; 
    case "7":
        if(move_to=="4" || move_to=="8"){
            return true;
        }
        break; 
    case "8":
        if(move_to=="7" || move_to=="5" || move_to=="9"){
            return true;
        }
        break;
    case "9":
        if(move_to=="8" || move_to=="6"){
            return true;
        }
        break; 
    default: 
      return false;
} 
    return false;

};