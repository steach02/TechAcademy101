﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PapaBobsPizzaChallenge
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void goBtn_Click(object sender, EventArgs e)
        {
            double total;

            if (RBSm.Checked)
            {
                total = 10;
            }
            else if (RBMd.Checked)
            {
                total = 13;
            }
            else
            {
                total = 16;
            }
            if (RbDeep.Checked)
            {
                total += 2;
            }
            if (CBPep.Checked)
            {
                total += 1.5;
            }
            if (CBOn.Checked)
            {
                total += .75;
            }
            if (CBGP.Checked)
            {
                total += .5;
            }
            if (CBRP.Checked)
            {
                total += .75;
            }
            //if we wanted to use ternary
            total = (CBAn.Checked) ? total + 2 : total;

            if ((CBPep.Checked&&CBGP.Checked&&CBAn.Checked) || (CBPep.Checked&&CBRP.Checked&&CBOn.Checked))
            {
                total -= 2;
            }
            resultLbl.Text = "Total:"+total;
        }
    }
}