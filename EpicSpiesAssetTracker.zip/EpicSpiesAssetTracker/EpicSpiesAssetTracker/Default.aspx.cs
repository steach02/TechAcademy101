﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EpicSpiesAssetTracker
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                int[] elections = new int[100];
                int[] subterfuge = new int[100];
                string[] name = new string[100];

                int index = 0;

                ViewState.Add("elections", elections);
                ViewState.Add("subterfuge", subterfuge);
                ViewState.Add("name", name);
                ViewState.Add("index", index);
            }
        }

        protected void goBtn_Click(object sender, EventArgs e)
        {
            //make sure the boxes are filled
            if (TBName.Text.Equals("") || TBElections.Text.Equals("") || TBSubterfuge.Text.Equals(""))
            {
                return;
            }

            //get the arrays from viewState
            int[] elections = (int[])ViewState["elections"];
            int[] subterfuge = (int[])ViewState["subterfuge"];
            string[] name = (string[])ViewState["name"];

            int index = (int)ViewState["index"];
            //if we are close to filling the array add some more space
            if ((index % 100) > 90)
            {
                Array.Resize(ref elections, 100);
                Array.Resize(ref subterfuge, 100);
                Array.Resize(ref name, 100);
            }
            //add new asset to the arrays
            elections[index] = int.Parse(TBElections.Text);
            subterfuge[index] = int.Parse(TBSubterfuge.Text);
            name[index] = TBName.Text;

            //display
            resultLbl.Text = "Total Elections Rigged: " + elections.Sum() + "<br/>Average Acts of Subterfuge per Asset: " + subterfuge.Sum() / (index + 1) + "<br/>(Last Asset you Added: " + name[index] + ")";

            //update the index
            index++;

            //update the viewState
            ViewState["elections"] = elections;
            ViewState["subterfuge"] = subterfuge;
            ViewState["name"] = name;
            ViewState["index"] = index;
        }
    }
}

