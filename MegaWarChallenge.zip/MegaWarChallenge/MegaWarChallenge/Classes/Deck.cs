﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MegaWarChallenge
{
    public class Deck
    {
        private List<Card> deck;
        public Deck()
        {
            deck = new List<Card>();
            for (int i = 2; i<15; i++)
            {

                deck.Add(new Card() { suit = "Diamonds", value = i});
                deck.Add(new Card() { suit = "Spades", value = i });
                deck.Add(new Card() { suit = "Hearts", value = i });
                deck.Add(new Card() { suit = "Clubs", value = i });

            }
        }
        public bool isDeckEmpty()
        {
            if (deck.Count  == 0) { return true; }
            return false;
        }
        public Card getCard(Random r)
        {
            int i = r.Next(0, deck.Count());
            Card c = deck[i];
            deck.Remove(deck[i]);
            return c;
        }
    }
}