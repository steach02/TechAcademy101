﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MegaWarChallenge
{
    public class Player
    {
        public List<Card> PlayerHand{ get; set; }

        public string Name { get; set; }
        public Player()
        {
            PlayerHand = new List<Card>();
        }
        public Card getCard()
        {
            Card c = PlayerHand[0];
            PlayerHand.Remove(c);
            return c;
        }
        public bool isHandEmpty()
        {
            return PlayerHand.Count == 0;
        }

    }
}