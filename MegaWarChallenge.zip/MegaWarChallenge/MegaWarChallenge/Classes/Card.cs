﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MegaWarChallenge
{
    public class Card
    {
        public string suit { get; set; }
        public int value { get; set; }
        public string toString()
        {
            if (value == 14) { return "Ace of " + suit; }
            else if (value == 11) { return "Jack of " + suit; }
            else if (value == 12) { return "Queen of " + suit; }
            else if (value == 13) { return "King of " + suit; }
            else { return value + " of " + suit;  }
        }
    }
}