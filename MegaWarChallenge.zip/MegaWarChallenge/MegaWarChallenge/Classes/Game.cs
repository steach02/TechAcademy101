﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MegaWarChallenge
{
    public class Game
    {
        private Player p1;
        private Player p2;
        private Player winner;
        private Deck deck;
        Random r;
        int rounds;
        public Game(int rounds)
        {
            p1 = new Player() { Name = "Player1"};
            p2 = new Player() { Name = "Player2"};
            deck = new Deck();
            r = new Random();
            this.rounds = rounds;

            Deal(p1,p2);
            
        }

        private void Deal(Player p1, Player p2)
        {
            while (!deck.isDeckEmpty())
            {
                p1.PlayerHand.Add(deck.getCard(r));
                p2.PlayerHand.Add(deck.getCard(r));
            }
        }

        public String Play()
        {
            //logic for card hadling we need the winner and bounty
            Dictionary<Player, List<Card>> result = new Dictionary<Player, List<Card>>();
            
            Card p1card = p1.getCard();
            Card p2card = p2.getCard();
             string resultString = "";
          
            if (p1card.value == p2card.value)
            {
                result = War(p1card, p2card);
                giveBounty(result);
            }
            else
            {
                if (p1card.value > p2card.value)
                {
                    result.Add(p1, new List<Card> { p1card, p2card });
                    giveBounty(result);

                }
                else
                {
                    result.Add(p2, new List<Card> { p1card, p2card });
                    giveBounty(result);

                }
            }
            rounds--;
            resultString = printRound(result);
            return resultString;
        }

        private void giveBounty(Dictionary<Player, List<Card>> result)
        {
            Player temp = result.ElementAt(result.Count-1).Key;
            temp.PlayerHand.AddRange(result[temp]);
        }

        private Dictionary<Player,List<Card>> War(Card p1card, Card p2card)
        {
            Dictionary<Player, List<Card>> result = new Dictionary<Player, List<Card>>();
            List<Card> bounty = new List<Card>();

            Card temp1 = p1.getCard();
            Card temp2 = p1.getCard();
            for (int i = 1; i<3; i++)
            {               
                    bounty.Add(p1.getCard());
                    bounty.Add(p2.getCard());                                
            }
            if (temp1.value > temp2.value)
            {
                bounty.Add(p1card);
                bounty.Add(p2card);
                bounty.Add(temp1);
                bounty.Add(temp2);
                result.Add(p1, bounty);   
            }
            else if (temp1.value < temp2.value)
            {
                bounty.Add(p1card);
                bounty.Add(p2card);
                bounty.Add(temp1);
                bounty.Add(temp2);
                result.Add(p2, bounty);
            }
            if (temp1.value == temp2.value)
            {
                Dictionary<Player, List<Card>> temp = War(temp1, temp2);

                bounty.AddRange(temp.ElementAt(temp.Count - 1).Value);
                bounty.Add(p1card);
                bounty.Add(p2card);
                result.Add(temp.ElementAt(temp.Count - 1).Key, bounty);
            } 
            return result;
        }

        public string printDeal()
        {
            String resultString = "";
            for (int i = 0; i < p1.PlayerHand.Count; i++)
            {
                resultString += p1.Name + " is dealt the " + p1.PlayerHand[i].toString() + "</br>";
                resultString += p2.Name + " is dealt the " + p2.PlayerHand[i].toString() + "</br>";
            }
            return resultString;
        }

        private string printRound(Dictionary<Player, List<Card>> result)
        {
            Player winner = result.ElementAt(0).Key;
            List<Card> bounty = result[winner];
            string war = "";

            if (bounty.Count>2) { war = "***************WAR***************"; }

            string resultString = war+"</br>Battle Cards: "+bounty[0].toString()+" VS "+bounty[1].toString()+"</br>Bounty ...<br>  ";
            foreach (Card c in bounty)
            {
                resultString += c.toString() + "</br>";
            }
            resultString += winner.Name + " wins!</br>";

            return resultString;
        }

        public string printGameOver()
        {
            return string.Format("</br>"+winner.Name + " wins! </br>" + p1.Name + ": {0}</br>" + p2.Name + ": {1}", p1.PlayerHand.Count, p2.PlayerHand.Count); ;
        }

        public bool gameOver()
        {
            if (rounds <= 0)
            {
                if (p1.PlayerHand.Count() > p2.PlayerHand.Count())
                {
                    winner = p1; return true;
                }
                else if (p2.PlayerHand.Count() > p1.PlayerHand.Count())
                {
                    winner = p2; return true;
                }
                else
                {
                    //incase of tie play another round
                    return false;
                }
            }
            else
            {
                return false;
            }
            
        }
    }
}