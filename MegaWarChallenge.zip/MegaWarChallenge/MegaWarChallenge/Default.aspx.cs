﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MegaWarChallenge
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void PlayButton_Click(object sender, EventArgs e)
        {
            Game g = new Game(20);
            resultLbl.Text = "<b>Begin Battle!!</b></br>";
            resultLbl.Text += g.printDeal();
            while (!g.gameOver())
            {
                resultLbl.Text += g.Play();
            }
            resultLbl.Text += g.printGameOver();

            //Card,Deck,Player Check
            //Constructor Check
            //Deal Check
            //printDeal Check
            //gameOver Check
            //printRound checked
            //giveBounty Checked
            //printGameOver Checked
            //War checked

            //Play: 

        }
    }
}