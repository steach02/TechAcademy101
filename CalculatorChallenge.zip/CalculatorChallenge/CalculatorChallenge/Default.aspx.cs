﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CalculatorChallenge
{
    public partial class Default : System.Web.UI.Page
    {
        long val1, val2;
        String result;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnPlus_Click(object sender, EventArgs e)
        {
            long val1 = long.Parse(TBFirst.Text);
            long val2 = long.Parse(TBSecond.Text);

            result = val1 + val2 + "";

            resultLbl.Text = result;
        }

        protected void BtnMin_Click(object sender, EventArgs e)
        {
            long val1 = long.Parse(TBFirst.Text);
            long val2 = long.Parse(TBSecond.Text);

            result = val1 - val2 + "";

            resultLbl.Text = result;
        }

        protected void BtnMul_Click(object sender, EventArgs e)
        {
            long val1 = long.Parse(TBFirst.Text);
            long val2 = long.Parse(TBSecond.Text);

            result = val1 * val2 + "";

            resultLbl.Text = result;
        }

        protected void BtnDiv_Click(object sender, EventArgs e)
        {
            double val1 = double.Parse(TBFirst.Text);
            double val2 = double.Parse(TBSecond.Text);

            result = val1 / val2 + "";

            resultLbl.Text = result;
        }
    }
}
