﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _default : System.Web.UI.Page
    {
        long val1, val2;
        String result;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        
        protected void divBtn_Click(object sender, EventArgs e)
        {
            double val1 = double.Parse(firstValue.Text);
            double val2 = double.Parse(secondValue.Text);

            result = val1 / val2 + "";

            resultLbl.Text = result;
        }

        protected void multButn_Click(object sender, EventArgs e)
        {
            long val1 = long.Parse(firstValue.Text);
            long val2 = long.Parse(secondValue.Text);

            result = val1 * val2 + "";

            resultLbl.Text = result;
        }

        protected void minusBtn_Click(object sender, EventArgs e)
        {
            long val1 = long.Parse(firstValue.Text);
            long val2 = long.Parse(secondValue.Text);

            result = val1 - val2 + "";

            resultLbl.Text = result;
        }

        protected void plusBtn_Click(object sender, EventArgs e)
        {
            long val1 = long.Parse(firstValue.Text);
            long val2 = long.Parse(secondValue.Text);

            result = val1 + val2 + "";

            resultLbl.Text = result;
        }
    }
}