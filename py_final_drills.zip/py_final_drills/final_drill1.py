import datetime
from datetime import datetime


open_time=9
close_time=21
bst=8
eastern=3
def checkOffices():
    current_Local_Time=datetime.now().hour
    if current_Local_Time+bst<open_time or current_Local_Time+bst>close_time:
        print('London office is closed')
    else:
        print('London office is Open')
    if current_Local_Time+eastern<open_time or current_Local_Time+eastern>close_time:
        print ('New York office is closed')
    else:
        print('New York office is Open')

checkOffices()
