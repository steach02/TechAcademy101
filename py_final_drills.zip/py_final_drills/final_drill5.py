import shutil
import os
import datetime
import sqlite3
import time
from datetime import timedelta
from datetime import datetime
from tkinter import filedialog
from tkinter import *
from tkinter import ttk
from tkinter import messagebox


#Globals
root = Tk()
source = ""
dest = ""
text1 = StringVar()
text2 = StringVar()
lastUpdated = StringVar()
conn = sqlite3.connect('my_db.db')
c = conn.cursor()

#View
button1 = ttk.Button(root, text = "Set Source")
button2 = ttk.Button(root, text = "Set Destination")
button3 = ttk.Button(root, text = "Transfer")
lable1 = Label(root, text="set Daily Check folder")
lable2 = Label(root, text="set Copied folder")
lable3 = Label(root, text="Manule File Check")
lable4 = Label(root, textvariable = text1)
lable5 = Label(root, textvariable = text2)
lable6 = Label(root, textvariable = lastUpdated)
lable1.pack()
button1.pack()
lable4.pack()
lable2.pack()               
button2.pack()
lable5.pack()
lable3.pack()
button3.pack()
lable6.pack()
root.title("drill3")
root.geometry('400x250')

#set Source directory
def setSource():
    global source
    source = filedialog.askdirectory()
    text1.set(source)
    
#set destination directory
def setDest():
    global dest
    dest = filedialog.askdirectory()
    text2.set(dest)

#move the files
    
def move_file(file_path):
    enter_data()
    files = os.listdir(source)
    for f in files:
        shutil.copy(file_path,dest)

#test which files have been modified within the last 24 hrs 
def test_for_transfer():
    if source == "" or dest == "":
        messagebox.showinfo("Error", "Sorry you must set the Daily Check folder and the Copied To folder befor running the manule file check")
    else:
        files = os.listdir(source)
        for f in files:
            file_path = source+"/"+f
            stamp = os.stat(file_path).st_mtime
            current_dt = datetime.now()
            modified_dt = datetime.fromtimestamp(stamp)
            temp = current_dt-modified_dt
            t = timedelta(days=1)
            if temp < t:
                move_file(file_path)
    get_Last_Updated()
#create new table if needed                
def create_table():
    c.execute('CREATE TABLE IF NOT EXISTS timeStamp(dateTimeStamp Text)')

#enter new time stamp    
def enter_data():
    unix=time.time()
    timeStamp = str(datetime.fromtimestamp(unix).strftime('%Y-%m-%d %H:%M:%S'))
    c.execute("Insert INTO timeStamp (dateTimeStamp) VALUES(?)",(timeStamp,))
    conn.commit()
#get the time stamp from the previouse update    
def get_Last_Updated():
    c.execute("SELECT * FROM timeStamp ORDER BY dateTimeStamp DESC LIMIT 1")
    data = c.fetchone()
    lastUpdated.set(data[0])

#set callback functions for the buttons
button1.config(command = setSource)
button2.config(command = setDest)
button3.config(command = test_for_transfer)
create_table()
get_Last_Updated()
