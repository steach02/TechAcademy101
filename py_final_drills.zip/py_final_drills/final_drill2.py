import shutil
import os


source = "/Users/amandapleasantbrown/Desktop/Folder_A"
dest = "/Users/amandapleasantbrown/Desktop/Folder_B"
def move_file():
    files = os.listdir(source)
    for f in files:
        file_path = source+"/"+f
        print(file_path)
        shutil.move(file_path,dest)
