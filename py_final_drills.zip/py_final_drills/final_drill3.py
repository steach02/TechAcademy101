import shutil
import os
import datetime
from datetime import timedelta
from datetime import datetime


source = "/Users/amandapleasantbrown/Desktop/Folder_A"
dest = "/Users/amandapleasantbrown/Desktop/Folder_B"
def move_file(file_path):
    files = os.listdir(source)
    for f in files:
        print(file_path)
        shutil.copy(file_path,dest)
def test_for_transfer():
    files = os.listdir(source)
    # run a loop to test each file
    for f in files:
        #get the file
        file_path = source+"/"+f
        #get the last modification time of the file
        stamp = os.stat(file_path).st_mtime
        current_dt = datetime.now()
        #see if it was mdified less than 24 hours prior
        modified_dt = datetime.fromtimestamp(stamp)
        temp = current_dt-modified_dt
        t = timedelta(days=1)
        if temp < t:
            move_file(file_path)
        
test_for_transfer()
