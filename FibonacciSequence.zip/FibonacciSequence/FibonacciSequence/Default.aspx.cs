﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FibonacciSequence
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Random r;
            if (!IsPostBack)
            {
                r = new Random();
                ViewState.Add("random", r);
            }
        }

        protected void FindBtn_Click(object sender, EventArgs e)
        {
            long n;
            long.TryParse(intTextBox.Text, out n);

            resultLbl.Text = fibonacci(n);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Random r = (Random)ViewState["random"];

            getNumberResultLbl.Text = getFibonacciNumber(r);
        }

        private string getFibonacciNumber(Random r)
        {
            long index = r.Next(1, 93);
            long a = 1;
            long b = 0;
            for (int i = 1; i< index; i++ )
            {
                long temp = a + b;
                b = a;
                a = temp;
            }

            return a + ", index = " + index;
        }
        
        private string fibonacci(long result)
        {
            //seq  n+1 = n + n-1
            long a = 1;
            long b = 0;
            long index = 1;
            string s = a + "";
            while (a < result)
            {
                long temp = a + b;
                b = a;
                a = temp;
                s += ", " + a;

                index++;
            }
           
                return s + "</br> index = " + index;

            
        }
    }
}