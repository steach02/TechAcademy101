﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace radioBtnChallenge
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void goBtn_Click(object sender, EventArgs e)
        {
            if (RBPencil.Checked)
            {
                resultLbl.Text = "You selected Pencil";
                image.ImageUrl = "~/images/pencil.png";
            }
            else if (RBPen.Checked)
            {
                resultLbl.Text = "You selected Pen";
                image.ImageUrl = "~/images/pen.png";
            }
            else if (RBPhone.Checked)
            {
                resultLbl.Text = "You selected Phone";
                image.ImageUrl = "~/images/phone.jpg";
            }
            else if (RBTablet.Checked)
            {
                resultLbl.Text = "You selected Tablet";
                image.ImageUrl = "~/images/tablet.jpg";
            }
            else
            {
                resultLbl.Text = "Please Make a Selection.";
            }
        }
    }
}