﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeForXmenBattleCount
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Wolverine fewest battles
            // Pheonix most battles

            string[] names = new string[] { "Professor X", "Iceman", "Angel", "Beast", "Pheonix", "Cyclops", "Wolverine", "Nightcrawler", "Storm", "Colossus" };
            int[] numbers = new int[] { 7, 9, 12, 15, 17, 13, 2, 6, 8, 13 };

            string result = "";


            // Your Code Here!
            int low = numbers[0];
            int lowIndex = 0;
            int high = numbers[0];
            int highIndex = 0;
            for (int i = 1; i < numbers.Length; i++)
            {
                if (numbers[i]<low)
                {
                    low = numbers[i];
                    lowIndex = i;
                }
                if (numbers[i]>high)
                {
                    high = numbers[i];
                    highIndex = i;
                }
                 
            }
            
            resultLabel.Text = "Most battles belong to: "+names[highIndex]+" (Value of: "+high+")<br>Least battels belong to: "+names[lowIndex]+" (Value of: "+low+")";
        }
    }
}