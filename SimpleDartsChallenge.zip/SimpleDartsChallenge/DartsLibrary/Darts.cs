﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DartsLibrary
{
    public class Darts
    {
        private Random _random;
        private int dartHit = 0;
        private int multiplier = 1;
        

        public Darts(Random random)
        {
            _random = random;
        }

        public void throwDart()
        {
            //where did the dart hit
            //1-20 even chance
            dartHit = _random.Next(0,21);
            int temp = _random.Next(1, 101);
            if (dartHit == 0 && temp < 5) { multiplier = 2; }
            else if (temp < 5) { multiplier = 2; }
            else if (temp >5 && temp < 11) { multiplier = 3; }
            else { multiplier = 1; }
        }
        public int getDartHit() { return dartHit; }
        public int getMultiplier() { return multiplier; }
    }
}
