﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SimpleDartsChallenge
{
    public class Score
    {
        public static int getScore(int[,] dartThrows) {
            int result = 0;
            for (int i = 0; i<3; i++) { result += dartThrows[0,i] * dartThrows[1,i]; }
            return result;
        }
    }
}