﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SimpleDartsChallenge
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void playButton_Click(object sender, EventArgs e)
        {
            Game g = new Game();
            printGame(g.play());
        }

        private void printGame(int[] playerScores)
        {
            player1Lbl.Text = "Player1: " + playerScores[0].ToString()+"</br>";
            player2Lbl.Text = "Player2: " + playerScores[1].ToString()+"</br>";
            resultLbl.Text = (playerScores[0] > playerScores[1]) ? "Winner: Player1" : "Winner: Player2";
        }
    }
}