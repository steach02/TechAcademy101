﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DartsLibrary;

namespace SimpleDartsChallenge
{
    public class Game
    {
        Random r = new Random();
        Darts d;
        public Game()
        {
            d = new Darts(r);
        }
        public int[] play()
        {
            Boolean b = false;
            int[] scores = new int[2];
            int p1Score = 0;
            int p2Score = 0;

            while (!b)
            {
                p1Score += throwDarts();
                p2Score += throwDarts();

                if (p1Score > 300 || p2Score > 300){ b = true; }
            }
            scores[0] = p1Score;
            scores[1] = p2Score;
            return scores;
        }

        private int throwDarts()
        {
            int result = 0;
            int[,] arr = new int[2,3];

            for (int i = 0; i<3; i++)
            {
                d.throwDart();
                arr[0, i] = d.getDartHit();
                arr[1, i] = d.getMultiplier();
            }
            result = Score.getScore(arr);
            return result;
        }
    }
}