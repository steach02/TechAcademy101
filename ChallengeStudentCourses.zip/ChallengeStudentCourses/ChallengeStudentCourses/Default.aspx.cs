﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeStudentCourses
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void assignment1Button_Click(object sender, EventArgs e)
        {
            /*
             * Create a List of Courses (add three example Courses ...
             * make up the details).  Each Course should have at least two
             * Students enrolled in them.  Use Object and Collection
             * Initializers.  Then, iterate through each Course and print
             * out the Course's details and the Students that are enrolled in
             * each Course.
             */
            resultLabel.Text = "";

            List<Course> courses = new List<Course>()
            {
                new Course() { CourseId = 1, Name = "Math 140",
                Students = new List<Student>() {
                    new Student() { Name = "Tom Hanks", StudentId = 1111},
                    new Student() { Name = "Tom Sawyer", StudentId = 1112} } },
                new Course() { CourseId = 2, Name = "Englis 102",
                Students = new List<Student>() {
                    new Student() { Name = "Alber Einstien", StudentId = 1113},
                    new Student() { Name = "John doe", StudentId = 1114} } },
                new Course() { CourseId = 3, Name = "Greek Mythology",
                Students = new List<Student>() {
                    new Student() { Name = "Amanda Pleasant-Brown", StudentId = 1115},
                    new Student() { Name = "Sarah Lee", StudentId = 1116} } }

            };

            foreach (Course c in courses)
            {
                resultLabel.Text += String.Format("<br/>Course: {0} - {1}", c.CourseId, c.Name);
                foreach (Student s in c.Students)
                {
                    resultLabel.Text += String.Format("<br/>Student: {0} - {1}", s.StudentId, s.Name );
                }
            }


        }

        protected void assignment2Button_Click(object sender, EventArgs e)
        {
            /*
             * Create a Dictionary of Students (add three example Students
             * ... make up the details).  Use the StudentId as the 
             * key.  Each student must be enrolled in two Courses.  Use
             * Object and Collection Initializers.  Then, iterate through
             * each student and print out to the web page each Student's
             * info and the Courses the Student is enrolled in.
             */
            resultLabel.Text = "";

            Course geometry = new Course() { CourseId = 12, Name = "Geometry" };
            Course english101 = new Course() { CourseId = 13, Name = "English101" };
            Course spanish = new Course() { CourseId = 14, Name = "Spanish" };

            Dictionary<int, Student> students = new Dictionary<int, Student>()
            {
                { 1111, new Student() {StudentId = 1111, Name = "Tom Hanks",  Courses = new List<Course>() { geometry,spanish } } },
                { 1117, new Student() {StudentId = 1117, Name = "Leah Kratzer",  Courses = new List<Course>() { english101,spanish } } },
                { 1118, new Student() {StudentId = 1118, Name = "Ali Johns",  Courses = new List<Course>() { geometry,english101 }} }
            };

            foreach (var s in students)
            {
                resultLabel.Text += String.Format("<br/>Student: {0} - {1}", s.Value.StudentId, s.Value.Name);
                foreach (Course c in s.Value.Courses)
                {
                    resultLabel.Text += String.Format("<br/>Course: {0} - {1}", c.CourseId, c.Name);
                }
            }

        }

        protected void assignment3Button_Click(object sender, EventArgs e)
        {
            /*
             * We need to keep track of each Student's grade (0 to 100) in a 
             * particular Course.  This means at a minimum, you'll need to add 
             * another class, and depending on your implementation, you will 
             * probably need to modify the existing classes to accommodate this 
             * new requirement.  Give each Student a grade in each Course they
             * are enrolled in (make up the data).  Then, for each student, 
             * print out each Course they are enrolled in and their grade.
             */
            resultLabel.Text = "";
            Course geometry = new Course() { CourseId = 12, Name = "Geometry" };
            Course english101 = new Course() { CourseId = 13, Name = "English101" };
            Course spanish = new Course() { CourseId = 14, Name = "Spanish" };

            Dictionary<int, Student> students = new Dictionary<int, Student>()
            {
                { 1111, new Student() {StudentId = 1111, Name = "Tom Hanks",  Courses = new List<Course>() { geometry,spanish }, CourseGrade = new Dictionary<Course, Grade>{ {geometry, new Grade() { Score = 100 } }, {spanish, new Grade() { Score = 100} } } } },
                { 1117, new Student() {StudentId = 1117, Name = "Leah Kratzer",  Courses = new List<Course>() { english101,spanish }, CourseGrade = new Dictionary<Course, Grade>{ {english101, new Grade() { Score = 100 } }, {spanish, new Grade() { Score = 100} } } } },
                { 1118, new Student() {StudentId = 1118, Name = "Ali Johns",  Courses = new List<Course>() { geometry,english101 }, CourseGrade = new Dictionary<Course, Grade>{ {geometry, new Grade() { Score = 100 } }, { english101, new Grade() { Score = 100} } } } }
            };

            foreach (var s in students)
            {
                resultLabel.Text += String.Format("<br/>Student: {0} - {1}", s.Value.StudentId, s.Value.Name);
                foreach (Course c in s.Value.Courses)
                {
                    resultLabel.Text += String.Format("<br/>Course: {0} - {1}: Grade - {2}", c.CourseId, c.Name, s.Value.CourseGrade[c].Score);
                }
            }

        }
    }
}