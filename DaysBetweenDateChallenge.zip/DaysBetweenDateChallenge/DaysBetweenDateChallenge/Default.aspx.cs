﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DaysBetweenDateChallenge
{
    public partial class Default : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void goBtn_Click(object sender, EventArgs e)
        {
            DateTime first = cal1.SelectedDate;
            DateTime second = cal2.SelectedDate;
            TimeSpan Temp;
            if (first > second)
            {
                Temp = first.Subtract(second);
            }
            else
            {
                Temp = second.Subtract(first);
            }
            resultLbl.Text = Temp.TotalDays.ToString();
        }
    }
}